from abs_class import AbsClass

class MyClass(AbsClass):
    def do_something(self, value):
        print('Doing %s.' % value)