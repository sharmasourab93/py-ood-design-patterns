class MyClass:
    def 