class Shipper(object):
    fedex = 1
    ups = 2
    postal = 3