from observer.observer_abc import AbsObserver
from observer.subject_abc import AbsSubject