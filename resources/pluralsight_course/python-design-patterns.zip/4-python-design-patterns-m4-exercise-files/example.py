class MyClass:
    """A simple example class"""
    i = 12345

    def f(self):
        return 'hello world'

m = MyClass()
r = m.f()
print(r)