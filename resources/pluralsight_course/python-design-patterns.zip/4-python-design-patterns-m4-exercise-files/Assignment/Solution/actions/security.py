class Security(object):
    def arm(self):
        print ('Security system armed')

    def disarm(self):
        print('Security disarmed')