import sys
print("We running Python Version: " + sys.version)
