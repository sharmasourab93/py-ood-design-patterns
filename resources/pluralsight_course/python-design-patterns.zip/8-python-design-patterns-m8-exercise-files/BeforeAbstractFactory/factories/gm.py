class ChevySpark:
    def start(self):
        print('Chevy Spark running efficiently.')
    def stop(self):
        print('Chevy Spark shutting down.')

class ChevyCamaro:
    def start(self):
        print('Chevy Camaro V8 sounding awesome!')
    def stop(self):
        print('Chevy Camaro shutting down.')

class CadillacCTS:
    def start(self):
        print('Cadillac CTS purring luxuriously.')
    def stop(self):
        print('Cadillac CTS shutting down.')
