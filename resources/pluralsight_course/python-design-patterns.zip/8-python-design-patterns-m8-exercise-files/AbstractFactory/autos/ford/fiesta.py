from autos.abs_auto import AbsAuto

class FordFiesta(AbsAuto):
	def start(self):
		print('Ford Fiesta running cheaply.')

	def stop(self):
		print('Ford Fiestashutting down.')
