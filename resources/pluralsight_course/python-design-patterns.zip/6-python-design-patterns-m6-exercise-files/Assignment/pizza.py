class Pizza(object):

    def display(self):
        print('Handmade Pizza:')
        print('\t{:>10}: {}'.format('Crust', self.crust))
        print('\t{:>10}: {}'.format('Sauce', self.sauce))
        print('\t{:>10}: {}'.format('Meat', self.meat))
        print('\t{:>10}: {}'.format('Vegies', self.vegies))
        print('\t{:>10}: {}'.format('Topping', self.topping))






