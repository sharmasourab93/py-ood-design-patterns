from computer import Computer

computer =  Computer()
computer.case = 'Coolermaster N300'
computer.mainboard = 'MSI 970'
computer.cpu = 'Intel Core i7-4770'
computer.memory = 'Corsair Vengeance 16GB'
computer.hard_drive = 'Seagate 2TB'
computer.video_card = 'GeForce GTX 1070'

computer.display()




