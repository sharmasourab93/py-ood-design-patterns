from testdata import ACCESSCONTROLS

class AccessControls:
    @staticmethod
    def get_access_control():
        return ACCESSCONTROLS
