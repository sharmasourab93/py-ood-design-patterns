class Employee:
    def __init__(self, empid, name, birthdate, salary):
        self.empid = empid
        self.name = name
        self.birthdate = birthdate
        self.salary = salary
