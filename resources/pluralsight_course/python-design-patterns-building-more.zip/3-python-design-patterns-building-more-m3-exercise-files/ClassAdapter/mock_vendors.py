from vend_adapter import VendorAdapter

MOCKVENDORS = (
    VendorAdapter('Dough Factory', 1, 'Semolina Court'),
    VendorAdapter('Farm Produce', 14, 'Country Rd.'),
    VendorAdapter('Cocoa World', 53, 'Tropical Blvd.')
)
