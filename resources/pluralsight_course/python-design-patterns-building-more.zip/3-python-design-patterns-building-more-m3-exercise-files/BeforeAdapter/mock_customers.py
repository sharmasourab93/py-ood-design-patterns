from customer import Customer

MOCKCUSTOMERS = (
    Customer('Pizza Love', '33 Pepperoni Lane'),
    Customer('Happy and Green', '25 Kale St.'),
    Customer('Sweet Tooth', '42 Chocolate Ave.')
)
