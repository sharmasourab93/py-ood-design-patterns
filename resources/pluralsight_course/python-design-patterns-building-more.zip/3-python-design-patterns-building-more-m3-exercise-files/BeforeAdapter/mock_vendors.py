from vendor import Vendor

MOCKVENDORS = (
    Vendor('Dough Factory', 1, 'Semolina Court'),
    Vendor('Farm Produce', 14, 'Country Rd.'),
    Vendor('Cocoa World', 53, 'Tropical Blvd.')
)
