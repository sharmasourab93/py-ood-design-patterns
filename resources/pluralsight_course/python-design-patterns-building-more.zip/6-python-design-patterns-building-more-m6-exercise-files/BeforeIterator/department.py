class Department(object):
    def __init__(self, deptid, name, date_established):
        self.deptid = deptid
        self.name = name
        self.date_established = date_established
