class Employee(object):
    def __init__(self, empid, name, hiredate):
        self.empid = empid
        self.name = name
        self.hiredate = hiredate
