class Employee(object):
    def __init__(self, number, name, date):
        self.number = number
        self.name = name
        self.date = date
