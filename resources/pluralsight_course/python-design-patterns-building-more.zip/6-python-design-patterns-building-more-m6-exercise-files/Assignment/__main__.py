from testtree import TESTTREE

def main():
    for node in TESTTREE:
        print(node.value)

if __name__ == '__main__':
    main()
