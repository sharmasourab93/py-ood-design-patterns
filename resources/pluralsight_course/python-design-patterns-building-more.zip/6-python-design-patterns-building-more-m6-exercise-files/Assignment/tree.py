class Tree:
    root = None

class Node:
    left = None
    right = None
    value = None

    def __init__(self, value):
        self.value = value
     