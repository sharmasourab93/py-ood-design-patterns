from abs_state import AbsState

class PaidFor(AbsState):
    pass
