class Person:
    name = None
    birthdate = None

    def __init__(self, name, birthdate):
        self.name = name
        self.birthdate = birthdate
