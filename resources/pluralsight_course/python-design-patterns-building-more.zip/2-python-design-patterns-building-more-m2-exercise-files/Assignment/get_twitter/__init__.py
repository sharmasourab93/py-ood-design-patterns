TOKEN = '<Access Token>'
TOKEN_SECRET = '<Access Token Secret>'
CONSUMER_KEY = '<Consumer Key (API Key)>'
CONSUMER_SECRET = '<Consumer Secret (API Secret)>'